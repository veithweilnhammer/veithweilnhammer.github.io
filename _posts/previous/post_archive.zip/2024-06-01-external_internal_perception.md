---
layout: post
title: External and internal modes of perception
date: 2024-06-01 12:00:00
description: How does perception balance new infomration with prior knowledge?
redirect: https://veithweilnhammer.github.io/assets/reveal/modes_Basel_2.html
tags: [teaching, consciousness, psychosis, perception]
---

Redirecting to another page.
