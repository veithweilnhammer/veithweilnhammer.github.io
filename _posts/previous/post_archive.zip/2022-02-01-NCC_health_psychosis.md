---
layout: post
title: The neural correlates of consciousness in health and in psychosis
date: 2022-02-01 17:39:00
description: What are the mechanisms that construct our experience of reality, and how do they fail in psychosis?
redirect: https://veithweilnhammer.github.io/assets/reveal/CCN.html
tags: [teaching, consciousness, psychosis]
---

Redirecting to another page.
