---
layout: post
title: Concepts and models of schizophrenia
date: 2022-04-01 13:00:00
description: How has the understanding of schizophrenia changed over time? 
redirect: https://veithweilnhammer.github.io/assets/pdf/Online_Lecture_Scz.pdf
tags: [teaching, schizophrenia   ]
---

Redirecting to another page.
